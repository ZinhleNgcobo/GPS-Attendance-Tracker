/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bl;

import java.util.List;
import javax.ejb.Local;
import za.ac.tut.entity.Attendance;

/**
 *
 * @author HP
 */
@Local
public interface AttendanceFacadeLocal {

    void create(Attendance attendance);

    void edit(Attendance attendance);

    void remove(Attendance attendance);

    Attendance find(Object id);

    List<Attendance> findAll();

    List<Attendance> findRange(int[] range);

    int count();
    
}
