/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.bl.AttendanceFacadeLocal;
import za.ac.tut.entity.Attendance;

/**
 *
 * @author HP
 */
public class CheckInServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ChechInServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ChechInServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    @EJB
    private AttendanceFacadeLocal afl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        double latitude = Double.parseDouble(request.getParameter("latitude"));
        double longitude = Double.parseDouble(request.getParameter("longitude"));
        
        //timestamp
        Date checkInTime = new Date();
        
        //attendance object
        Attendance attendance = createCheckIn(id,name,surname,latitude,longitude,checkInTime);
        afl.create(attendance);
        
        request.setAttribute("name", name);
        request.setAttribute("surname", surname);
        request.setAttribute("latitude", latitude);
        request.setAttribute("longitude", longitude);
        request.setAttribute("checkInTime", checkInTime);
        
        RequestDispatcher disp = request.getRequestDispatcher("checkin_outcome.jsp");
        disp.forward(request, response);
    }

    private Attendance createCheckIn(String id, String name, String surname, Double latitude, Double longitude,Date checkInTime){
        Attendance attendance = new Attendance();
        attendance.setId(id);
        attendance.setName(name);
        attendance.setSurname(surname);
        attendance.setLatitude(latitude);
        attendance.setLongitude(longitude);
        attendance.setCheckInTime(checkInTime);
        return attendance;
        
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
